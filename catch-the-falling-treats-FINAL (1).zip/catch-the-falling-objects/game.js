/* =========================================================
   CATCH THE FALLING OBJECTS
   Vanilla JavaScript + HTML5 Canvas
   ========================================================= */

"use strict";

// ---------- DOM REFERENCES ----------
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const gameFrame = document.getElementById("gameFrame");

const scoreValue = document.getElementById("scoreValue");
const highScoreValue = document.getElementById("highScoreValue");
const livesValue = document.getElementById("livesValue");
const levelValue = document.getElementById("levelValue");
const difficultyValue = document.getElementById("difficultyValue");

const menuOverlay = document.getElementById("menuOverlay");
const countdownOverlay = document.getElementById("countdownOverlay");
const countdownText = document.getElementById("countdownText");
const pauseOverlay = document.getElementById("pauseOverlay");
const gameOverOverlay = document.getElementById("gameOverOverlay");

const startButton = document.getElementById("startButton");
const resumeButton = document.getElementById("resumeButton");
const playAgainButton = document.getElementById("playAgainButton");
const menuButton = document.getElementById("menuButton");
const pauseButton = document.getElementById("pauseButton");
const muteButton = document.getElementById("muteButton");

const finalScore = document.getElementById("finalScore");
const finalHighScore = document.getElementById("finalHighScore");
const newHighScore = document.getElementById("newHighScore");

const leftTouch = document.getElementById("leftTouch");
const rightTouch = document.getElementById("rightTouch");

// ---------- GAME CONFIG ----------
const WORLD = { width: 900, height: 600 };
const MAX_PARTICLES = 280;
const MAX_OBJECTS = 20;
const HIGH_SCORE_KEY = "catchFallingObjectsHighScore";

const DIFFICULTIES = [
  { name: "EASY", threshold: 0, speed: 125, spawn: 950, maxObjects: 3 },
  { name: "MEDIUM", threshold: 10, speed: 150, spawn: 825, maxObjects: 4 },
  { name: "HARD", threshold: 25, speed: 178, spawn: 700, maxObjects: 5 },
  { name: "EXTREME", threshold: 45, speed: 210, spawn: 585, maxObjects: 6 }
];

const OBJECT_TYPES = [
  { type: "berry", points: 1, color: "#ff7098", glow: "rgba(255,112,152,0.42)" },
  { type: "star", points: 2, color: "#ffd34f", glow: "rgba(255,211,79,0.45)" },
  { type: "cookie", points: 3, color: "#c98557", glow: "rgba(201,133,87,0.40)" }
];

// ---------- GAME STATE ----------
const game = {
  state: "MENU", // MENU | COUNTDOWN | PLAYING | PAUSED | GAME_OVER
  score: 0,
  lives: 3,
  level: 1,
  highScore: loadHighScore(),
  difficulty: DIFFICULTIES[0],
  objects: [],
  particles: [],
  popups: [],
  spawnTimer: 0,
  elapsed: 0,
  lastTime: 0,
  countdown: 0,
  countdownTimer: 0,
  muted: false,
  newHighScore: false,
  shake: 0
};

const input = {
  left: false,
  right: false
};

const player = {
  x: WORLD.width / 2 - 62,
  y: WORLD.height - 65,
  width: 124,
  height: 31,
  speed: 470,
  catchFlash: 0
};

// ---------- INITIALIZATION ----------
function init() {
  resizeCanvas();
  updateHUD();
  bindEvents();
  requestAnimationFrame(gameLoop);
}

function bindEvents() {
  window.addEventListener("resize", resizeCanvas);

  window.addEventListener("keydown", (event) => {
    const key = event.key.toLowerCase();

    if (["arrowleft", "arrowright", "a", "d", "p", "m", " "].includes(key)) {
      event.preventDefault();
    }

    if (key === "arrowleft" || key === "a") input.left = true;
    if (key === "arrowright" || key === "d") input.right = true;

    if (key === "p") togglePause();
    if (key === "m") toggleMute();

    if (key === " " && game.state === "MENU") startGame();
    if (key === "enter" && game.state === "GAME_OVER") startGame();
  });

  window.addEventListener("keyup", (event) => {
    const key = event.key.toLowerCase();
    if (key === "arrowleft" || key === "a") input.left = false;
    if (key === "arrowright" || key === "d") input.right = false;
  });

  startButton.addEventListener("click", startGame);
  resumeButton.addEventListener("click", () => {
    resumeGame();
  });
  playAgainButton.addEventListener("click", startGame);
  menuButton.addEventListener("click", showMainMenu);
  pauseButton.addEventListener("click", togglePause);
  muteButton.addEventListener("click", toggleMute);

  bindTouchButton(leftTouch, "left");
  bindTouchButton(rightTouch, "right");

  // Unlock Web Audio on the first meaningful interaction.
  document.addEventListener("pointerdown", initAudio, { once: true });
}

function bindTouchButton(button, direction) {
  const press = (event) => {
    event.preventDefault();
    initAudio();
    input[direction] = true;
  };
  const release = (event) => {
    event.preventDefault();
    input[direction] = false;
  };

  button.addEventListener("pointerdown", press);
  button.addEventListener("pointerup", release);
  button.addEventListener("pointercancel", release);
  button.addEventListener("pointerleave", release);
}

// ---------- CANVAS / RESPONSIVENESS ----------
function resizeCanvas() {
  // The logical canvas remains 900x600. CSS scales it responsively.
  // Device pixel ratio improves sharpness without changing game coordinates.
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = WORLD.width * dpr;
  canvas.height = WORLD.height * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

// ---------- GAME LOOP ----------
function gameLoop(timestamp) {
  if (!game.lastTime) game.lastTime = timestamp;
  const delta = Math.min((timestamp - game.lastTime) / 1000, 0.033);
  game.lastTime = timestamp;

  update(delta);
  render();

  requestAnimationFrame(gameLoop);
}

function update(delta) {

  if (game.state === "COUNTDOWN") {
    updateCountdown(delta);
    updateParticles(delta);
    updatePopups(delta);
    return;
  }

  if (game.state !== "PLAYING") {
    updateParticles(delta);
    updatePopups(delta);
    return;
  }

  game.elapsed += delta;
  game.spawnTimer += delta * 1000;
  game.shake = Math.max(0, game.shake - delta);
  player.catchFlash = Math.max(0, player.catchFlash - delta);

  updateDifficulty();
  updatePlayer(delta);
  updateObjects(delta);
  updateParticles(delta);
  updatePopups(delta);

  const spawnInterval = game.difficulty.spawn / 1000;
  if (game.spawnTimer >= spawnInterval && game.objects.length < game.difficulty.maxObjects) {
    game.spawnTimer = 0;
    createFallingObject();
  }
}

// ---------- COUNTDOWN ----------
function startCountdown() {
  game.state = "COUNTDOWN";
  game.countdown = 3;
  game.countdownTimer = 0;
  countdownText.textContent = "3";
  countdownOverlay.classList.add("active");
  playTone(480, 0.12, "sine", 0.035);
}

function updateCountdown(delta) {
  game.countdownTimer += delta;

  if (game.countdownTimer >= 1) {
    game.countdownTimer -= 1;
    game.countdown -= 1;

    if (game.countdown > 0) {
      countdownText.textContent = game.countdown;
      playTone(480 + (3 - game.countdown) * 90, 0.12, "sine", 0.035);
    } else {
      countdownText.textContent = "GO!";
      playTone(760, 0.2, "triangle", 0.05);

      setTimeout(() => {
        if (game.state === "COUNTDOWN") {
          countdownOverlay.classList.remove("active");
          game.state = "PLAYING";
        }
      }, 500);
    }
  }
}

// ---------- GAME STATE ----------
function startGame() {
  initAudio();
  resetGame();
  hideOverlay(menuOverlay);
  hideOverlay(gameOverOverlay);
  hideOverlay(pauseOverlay);
  pauseButton.classList.remove("hidden");
  game.state = "COUNTDOWN";
  startCountdown();
}

function resetGame() {
  game.score = 0;
  game.lives = 3;
  game.level = 1;
  game.difficulty = DIFFICULTIES[0];
  game.objects.length = 0;
  game.particles.length = 0;
  game.popups.length = 0;
  game.spawnTimer = 0;
  game.elapsed = 0;
  game.shake = 0;
  game.newHighScore = false;
  player.x = WORLD.width / 2 - player.width / 2;
  player.catchFlash = 0;
  updateHUD();
}

function togglePause() {
  if (game.state === "PLAYING") {
    game.state = "PAUSED";
    showOverlay(pauseOverlay);
    pauseButton.textContent = "▶";
    pauseButton.setAttribute("aria-label", "Resume game");
    playClick();
  } else if (game.state === "PAUSED") {
    resumeGame();
  }
}

function resumeGame() {
  if (game.state !== "PAUSED") return;
  hideOverlay(pauseOverlay);
  game.state = "PLAYING";
  pauseButton.textContent = "Ⅱ";
  pauseButton.setAttribute("aria-label", "Pause game");
  playClick();
}

function endGame() {
  game.state = "GAME_OVER";
  input.left = false;
  input.right = false;

  game.newHighScore = game.score > game.highScore;
  if (game.newHighScore) {
    game.highScore = game.score;
    saveHighScore(game.highScore);
  }

  finalScore.textContent = game.score;
  finalHighScore.textContent = game.highScore;
  newHighScore.classList.toggle("hidden", !game.newHighScore);

  pauseButton.classList.add("hidden");
  showOverlay(gameOverOverlay);

  createBurst(player.x + player.width / 2, player.y, "#ff6486", 22);
  playGameOver();
}

function showMainMenu() {
  resetGame();
  game.state = "MENU";
  hideOverlay(gameOverOverlay);
  hideOverlay(pauseOverlay);
  showOverlay(menuOverlay);
  pauseButton.classList.add("hidden");
  playClick();
}

function showOverlay(element) {
  element.classList.add("active");
}

function hideOverlay(element) {
  element.classList.remove("active");
}

// ---------- PLAYER ----------
function updatePlayer(delta) {
  const direction = Number(input.right) - Number(input.left);
  player.x += direction * player.speed * delta;
  player.x = clamp(player.x, 18, WORLD.width - player.width - 18);
}

function drawPlayer() {
  const x = player.x, y = player.y;
  ctx.save();
  if (player.catchFlash > 0) { ctx.shadowBlur = 28; ctx.shadowColor = "#ffd85c"; }
  ctx.strokeStyle = "#9a6a45"; ctx.lineWidth = 7; ctx.lineCap = "round";
  ctx.beginPath(); ctx.arc(x + player.width/2, y + 10, 45, Math.PI, Math.PI*2); ctx.stroke();
  ctx.strokeStyle = "#e1a46a"; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(x + player.width/2, y + 10, 45, Math.PI, Math.PI*2); ctx.stroke();
  const g = ctx.createLinearGradient(x,y,x,y+player.height);
  g.addColorStop(0,"#efbd73"); g.addColorStop(.55,"#d99351"); g.addColorStop(1,"#b9703e");
  ctx.fillStyle=g; roundedRect(ctx,x,y+7,player.width,player.height-7,12); ctx.fill();
  ctx.save(); roundedRect(ctx,x,y+7,player.width,player.height-7,12); ctx.clip();
  ctx.strokeStyle="rgba(255,238,184,.52)"; ctx.lineWidth=5;
  for(let i=-20;i<player.width+25;i+=22){ctx.beginPath();ctx.moveTo(x+i,y+5);ctx.lineTo(x+i+17,y+player.height);ctx.stroke();}
  ctx.strokeStyle="rgba(145,82,42,.32)";ctx.lineWidth=3;
  for(let yy=y+18;yy<y+player.height;yy+=12){ctx.beginPath();ctx.moveTo(x,yy);ctx.lineTo(x+player.width,yy);ctx.stroke();}
  ctx.restore();
  ctx.fillStyle="#f2c47d"; roundedRect(ctx,x-2,y+4,player.width+4,14,7);ctx.fill();
  ctx.strokeStyle="#b87543";ctx.lineWidth=2;roundedRect(ctx,x-2,y+4,player.width+4,14,7);ctx.stroke();
  ctx.fillStyle="#5c4c48";ctx.beginPath();ctx.arc(x+player.width/2-15,y+30,2.5,0,Math.PI*2);ctx.arc(x+player.width/2+15,y+30,2.5,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle="#5c4c48";ctx.lineWidth=2;ctx.beginPath();ctx.arc(x+player.width/2,y+30,8,.15,Math.PI-.15);ctx.stroke();
  ctx.restore();
}

// ---------- FALLING OBJECTS ----------
function createFallingObject() {
  const type = OBJECT_TYPES[Math.floor(Math.random() * OBJECT_TYPES.length)];
  const size = randomBetween(20, 28);
  const object = {
    ...type,
    x: randomBetween(30 + size, WORLD.width - 30 - size),
    y: -size - randomBetween(0, 100),
    size,
    rotation: randomBetween(0, Math.PI * 2),
    rotationSpeed: randomBetween(-1.5, 1.5),
    speed: game.difficulty.speed * randomBetween(0.88, 1.16),
    wobble: randomBetween(0, Math.PI * 2),
    wobbleSpeed: randomBetween(1.2, 2.2),
    age: 0
  };

  game.objects.push(object);
}

function updateObjects(delta) {
  for (let i = game.objects.length - 1; i >= 0; i--) {
    const object = game.objects[i];
    object.age += delta;
    object.y += object.speed * delta;
    object.rotation += object.rotationSpeed * delta;
    object.wobble += object.wobbleSpeed * delta;

    const drawX = object.x + Math.sin(object.wobble) * 7;

    if (checkCollision(player, { ...object, x: drawX })) {
      catchObject(object, drawX);
      game.objects.splice(i, 1);
      continue;
    }

    if (object.y - object.size > WORLD.height) {
      game.objects.splice(i, 1);
      missObject(object);
    }
  }
}

function catchObject(object, drawX) {
  game.score += object.points;
  player.catchFlash = 0.16;

  updateDifficulty();
  updateHUD();

  createBurst(drawX, object.y, object.color, object.type === "cookie" ? 18 : 12);
  addPopup(drawX, object.y - 20, `+${object.points}`, object.color);
  playCatch(object.points);
}

function missObject(object) {
  game.lives -= 1;
  game.shake = 0.25;

  createBurst(object.x, WORLD.height - 8, "#ff6486", 8);
  updateHUD();
  playMiss();

  gameFrame.classList.remove("shake");
  void gameFrame.offsetWidth;
  gameFrame.classList.add("shake");

  if (game.lives <= 0) endGame();
}

// ---------- COLLISION DETECTION ----------
function checkCollision(a, b) {
  // A forgiving rectangle/circle hybrid makes catching feel fair.
  const objectBottom = b.y + b.size * 0.72;
  const objectTop = b.y - b.size * 0.72;
  const objectLeft = b.x - b.size * 0.72;
  const objectRight = b.x + b.size * 0.72;

  const playerTop = a.y;
  const playerBottom = a.y + a.height;
  const playerLeft = a.x;
  const playerRight = a.x + a.width;

  return (
    objectRight >= playerLeft &&
    objectLeft <= playerRight &&
    objectBottom >= playerTop &&
    objectTop <= playerBottom
  );
}

// ---------- SCORE / DIFFICULTY ----------
function updateDifficulty() {
  let selected = DIFFICULTIES[0];

  for (const difficulty of DIFFICULTIES) {
    if (game.score >= difficulty.threshold) selected = difficulty;
  }

  const oldLevel = game.level;
  game.difficulty = selected;
  game.level = DIFFICULTIES.indexOf(selected) + 1;

  if (game.level > oldLevel && game.state === "PLAYING") {
    addPopup(WORLD.width / 2, 85, `${selected.name} • LEVEL ${game.level}`, "#68f5ae");
    createBurst(WORLD.width / 2, 95, "#68f5ae", 18);
    playLevelUp();
  }
}

function updateHUD() {
  scoreValue.textContent = game.score;
  highScoreValue.textContent = game.highScore;
  livesValue.textContent = `${game.lives >= 1 ? "♥" : "♡"} ${game.lives >= 2 ? "♥" : "♡"} ${game.lives >= 3 ? "♥" : "♡"}`;
  levelValue.textContent = game.level;
  difficultyValue.textContent = game.difficulty.name;
}

// ---------- PARTICLES ----------
function createBurst(x, y, color, count = 12) {
  for (let i = 0; i < count; i++) {
    if (game.particles.length >= MAX_PARTICLES) game.particles.shift();

    const angle = Math.random() * Math.PI * 2;
    const speed = randomBetween(50, 180);
    game.particles.push({
      x, y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life: randomBetween(0.35, 0.7),
      maxLife: 0.7,
      size: randomBetween(1.5, 4),
      color,
      gravity: randomBetween(30, 80)
    });
  }
}

function updateParticles(delta) {
  for (let i = game.particles.length - 1; i >= 0; i--) {
    const p = game.particles[i];
    p.life -= delta;
    p.x += p.vx * delta;
    p.y += p.vy * delta;
    p.vy += p.gravity * delta;

    if (p.life <= 0) game.particles.splice(i, 1);
  }
}

function drawParticles() {
  for (const p of game.particles) {
    ctx.save();
    ctx.globalAlpha = Math.max(0, p.life / p.maxLife);
    ctx.fillStyle = p.color;
    ctx.shadowBlur = 10;
    ctx.shadowColor = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

// ---------- SCORE POPUPS ----------
function addPopup(x, y, text, color) {
  game.popups.push({ x, y, text, color, life: 0.9, maxLife: 0.9 });
}

function updatePopups(delta) {
  for (let i = game.popups.length - 1; i >= 0; i--) {
    const popup = game.popups[i];
    popup.life -= delta;
    popup.y -= 35 * delta;
    if (popup.life <= 0) game.popups.splice(i, 1);
  }
}

function drawPopups() {
  ctx.save();
  ctx.textAlign = "center";
  ctx.font = "800 16px Nunito, sans-serif";

  for (const popup of game.popups) {
    ctx.globalAlpha = Math.min(1, popup.life * 2);
    ctx.fillStyle = popup.color;
    ctx.shadowBlur = 12;
    ctx.shadowColor = popup.color;
    ctx.fillText(popup.text, popup.x, popup.y);
  }

  ctx.restore();
}

// ---------- BACKGROUND ----------
function drawBackground() {
  // Bright daytime sky.
  const sky = ctx.createLinearGradient(0, 0, 0, WORLD.height);
  sky.addColorStop(0, "#63c9f0");
  sky.addColorStop(0.48, "#bdeefe");
  sky.addColorStop(0.72, "#e8f8d0");
  sky.addColorStop(1, "#a8df83");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, WORLD.width, WORLD.height);

  // Big friendly sun.
  ctx.save();
  ctx.globalAlpha = 0.34;
  ctx.fillStyle = "#ffe36d";
  ctx.beginPath();
  ctx.arc(770, 86, 92, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#ffe98a";
  ctx.beginPath();
  ctx.arc(770, 86, 38, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Puffy moving clouds.
  for (let i = 0; i < 4; i++) {
    const width = WORLD.width + 180;
    const cx = (i * 275 + 70 + game.elapsed * (5 + i * 1.5)) % width - 90;
    const cy = 68 + i * 54;
    const scale = 0.62 + (i % 2) * 0.18;
    drawCloud(cx, cy, scale);
  }

  // Distant rolling hills make the scene feel like a real picnic meadow.
  ctx.fillStyle = "#9fd987";
  ctx.beginPath();
  ctx.moveTo(0, 415);
  ctx.quadraticCurveTo(120, 345, 255, 414);
  ctx.quadraticCurveTo(390, 325, 540, 415);
  ctx.quadraticCurveTo(690, 330, 900, 405);
  ctx.lineTo(900, 530);
  ctx.lineTo(0, 530);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = "#83cb78";
  ctx.beginPath();
  ctx.moveTo(0, 452);
  ctx.quadraticCurveTo(140, 390, 290, 455);
  ctx.quadraticCurveTo(450, 385, 610, 454);
  ctx.quadraticCurveTo(770, 395, 900, 450);
  ctx.lineTo(900, 530);
  ctx.lineTo(0, 530);
  ctx.closePath();
  ctx.fill();

  // Cute trees at the edges.
  drawTree(72, 390, 1.05);
  drawTree(830, 398, 0.9);
  drawTree(145, 420, 0.72);
  drawTree(760, 425, 0.68);

  // Main picnic grass.
  const grass = ctx.createLinearGradient(0, 485, 0, WORLD.height);
  grass.addColorStop(0, "#a9e88e");
  grass.addColorStop(1, "#75c96f");
  ctx.fillStyle = grass;
  ctx.fillRect(0, 485, WORLD.width, 115);

  // Picnic blanket behind the basket.
  ctx.save();
  ctx.translate(450, 568);
  ctx.rotate(-0.02);
  ctx.fillStyle = "rgba(255,250,226,.9)";
  roundedRect(ctx, -175, -20, 350, 48, 10);
  ctx.fill();
  ctx.strokeStyle = "rgba(235,133,157,.55)";
  ctx.lineWidth = 7;
  for (let x = -145; x <= 145; x += 35) {
    ctx.beginPath(); ctx.moveTo(x, -18); ctx.lineTo(x, 26); ctx.stroke();
  }
  ctx.restore();

  // Foreground flowers and grass blades.
  for (let i = 0; i < 34; i++) {
    const x = (i * 71 + 19) % WORLD.width;
    const y = 505 + (i % 7) * 13;
    ctx.strokeStyle = i % 2 ? "#5eaf62" : "#66b968";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x, y + 18); ctx.lineTo(x + 2, y); ctx.stroke();
    if (i % 2 === 0) drawFlower(x, y, i % 4);
  }

  // Butterflies are deliberately large enough to be visible.
  drawButterfly(215 + Math.sin(game.elapsed * 1.4) * 22, 235 + Math.sin(game.elapsed * 1.9) * 18, "#ff83ad", 1);
  drawButterfly(615 + Math.sin(game.elapsed * 1.1 + 2) * 25, 285 + Math.cos(game.elapsed * 1.6) * 17, "#9b83e8", 0.9);
  drawButterfly(420 + Math.cos(game.elapsed * 1.2) * 18, 170 + Math.sin(game.elapsed * 1.7) * 14, "#ffcf54", 0.72);
}

function drawCloud(x, y, scale) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  ctx.fillStyle = "rgba(255,255,255,.88)";
  ctx.beginPath();
  ctx.arc(-35, 10, 23, 0, Math.PI * 2);
  ctx.arc(0, -7, 31, 0, Math.PI * 2);
  ctx.arc(35, 10, 23, 0, Math.PI * 2);
  ctx.roundRect(-58, 8, 116, 28, 14);
  ctx.fill();
  ctx.restore();
}

function drawTree(x, y, scale) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  ctx.fillStyle = "#a96e4b";
  roundedRect(ctx, -9, 22, 18, 72, 7);
  ctx.fill();
  ctx.fillStyle = "#5eae68";
  for (const [dx, dy, r] of [[-28,18,30],[0,-5,38],[28,18,30],[0,30,32]]) {
    ctx.beginPath(); ctx.arc(dx, dy, r, 0, Math.PI * 2); ctx.fill();
  }
  ctx.fillStyle = "rgba(255,255,255,.15)";
  ctx.beginPath(); ctx.arc(-10, -12, 13, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

function drawFlower(x, y, variant) {
  const petals = ["#ff88ad", "#ffd65b", "#ffffff", "#a98ce9"][variant];
  ctx.fillStyle = petals;
  for (let j = 0; j < 5; j++) {
    const a = j * Math.PI * 2 / 5;
    ctx.beginPath();
    ctx.arc(x + Math.cos(a) * 4, y + Math.sin(a) * 4, 3.4, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = "#ffd45a";
  ctx.beginPath(); ctx.arc(x, y, 2.2, 0, Math.PI * 2); ctx.fill();
}

function drawButterfly(x, y, color, scale) {
  const flap = 1 + Math.sin(game.elapsed * 9 + x) * 0.13;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale * flap, scale);
  ctx.fillStyle = color;
  ctx.beginPath(); ctx.ellipse(-9, -4, 10, 7, -0.35, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(9, -4, 10, 7, 0.35, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "#5c5360";
  ctx.beginPath(); ctx.roundRect(-2, -7, 4, 16, 2); ctx.fill();
  ctx.strokeStyle = "#5c5360"; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(-1, -6); ctx.quadraticCurveTo(-6, -12, -8, -10); ctx.moveTo(1, -6); ctx.quadraticCurveTo(6, -12, 8, -10); ctx.stroke();
  ctx.restore();
}

// ---------- OBJECT RENDERING ----------
function drawObject(object) {
  const x = object.x + Math.sin(object.wobble) * 7, y = object.y, s = object.size;
  ctx.save(); ctx.translate(x,y); ctx.rotate(object.rotation); ctx.shadowBlur=18; ctx.shadowColor=object.glow;
  if(object.type === "berry") drawBerry(s);
  if(object.type === "star") drawSunnyStar(s);
  if(object.type === "cookie") drawCookie(s);
  ctx.restore();
}
function drawBerry(s){
  ctx.fillStyle="#63c986";ctx.beginPath();ctx.ellipse(0,-s*.78,s*.36,s*.17,-.2,0,Math.PI*2);ctx.fill();
  const g=ctx.createRadialGradient(-s*.25,-s*.3,1,0,0,s);g.addColorStop(0,"#ffb0c8");g.addColorStop(.45,"#ff7098");g.addColorStop(1,"#e74f78");ctx.fillStyle=g;
  ctx.beginPath();ctx.arc(-s*.22,s*.05,s*.53,0,Math.PI*2);ctx.arc(s*.25,s*.05,s*.53,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="rgba(255,255,255,.8)";for(const q of [[-.25,-.05],[.05,.22],[.3,-.2],[-.42,.28]]){ctx.beginPath();ctx.arc(q[0]*s,q[1]*s,2,0,Math.PI*2);ctx.fill();}
}
function drawSunnyStar(s){
  ctx.fillStyle="#ffd34f";ctx.beginPath();for(let i=0;i<10;i++){const r=i%2?s*.42:s,a=-Math.PI/2+i*Math.PI/5,px=Math.cos(a)*r,py=Math.sin(a)*r;if(!i)ctx.moveTo(px,py);else ctx.lineTo(px,py);}ctx.closePath();ctx.fill();
  ctx.fillStyle="#fff1a6";ctx.beginPath();ctx.arc(-s*.2,-s*.25,s*.18,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="#725b42";ctx.beginPath();ctx.arc(-s*.22,s*.12,2,0,Math.PI*2);ctx.arc(s*.22,s*.12,2,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle="#725b42";ctx.lineWidth=1.8;ctx.beginPath();ctx.arc(0,s*.12,s*.2,.15,Math.PI-.15);ctx.stroke();
}
function drawCookie(s){
  ctx.fillStyle="#c98557";ctx.beginPath();ctx.arc(0,0,s*.78,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#a86643";ctx.lineWidth=2;ctx.stroke();
  ctx.fillStyle="#77452f";for(const q of [[-.35,-.28],[.24,-.36],[.38,.12],[-.12,.25],[-.42,.33],[.08,-.02]]){ctx.beginPath();ctx.arc(q[0]*s,q[1]*s,s*.1,0,Math.PI*2);ctx.fill();}
  ctx.fillStyle="rgba(255,226,183,.65)";ctx.beginPath();ctx.arc(-s*.3,-s*.35,s*.12,0,Math.PI*2);ctx.fill();
}

// ---------- RENDER ----------
function render() {
  ctx.save();

  if (game.shake > 0) {
    const amount = 4 * (game.shake / 0.25);
    ctx.translate(randomBetween(-amount, amount), randomBetween(-amount, amount));
  }

  drawBackground();

  // Decorative top guide.
  ctx.save();
  ctx.globalAlpha = 0.28;
  ctx.strokeStyle = "#6e7895";
  ctx.setLineDash([3, 12]);
  ctx.beginPath();
  ctx.moveTo(18, 45);
  ctx.lineTo(WORLD.width - 18, 45);
  ctx.stroke();
  ctx.restore();

  for (const object of game.objects) drawObject(object);
  drawPlayer();
  drawParticles();
  drawPopups();

  ctx.restore();
}

// ---------- AUDIO: WEB AUDIO FALLBACK ----------
let audioContext = null;

function initAudio() {
  try {
    if (!audioContext) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      audioContext = new AudioContext();
    }
    if (audioContext.state === "suspended") audioContext.resume();
  } catch {
    // Audio is optional; gameplay continues normally.
  }
}

function playTone(frequency, duration, type = "sine", volume = 0.04, endFrequency = null) {
  if (game.muted || !audioContext) return;

  try {
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();
    const now = audioContext.currentTime;

    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, now);
    if (endFrequency) oscillator.frequency.exponentialRampToValueAtTime(endFrequency, now + duration);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(volume, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    oscillator.connect(gain);
    gain.connect(audioContext.destination);
    oscillator.start(now);
    oscillator.stop(now + duration + 0.02);
  } catch {
    // Ignore unavailable audio devices/context errors.
  }
}

function playCatch(points) {
  playTone(420 + points * 90, 0.11, "triangle", 0.045, 720 + points * 80);
}

function playMiss() {
  playTone(170, 0.18, "sawtooth", 0.035, 100);
}

function playClick() {
  playTone(320, 0.07, "square", 0.025, 440);
}

function playLevelUp() {
  playTone(500, 0.1, "triangle", 0.035, 700);
  setTimeout(() => playTone(700, 0.13, "triangle", 0.035, 1000), 80);
}

function playGameOver() {
  playTone(360, 0.18, "sawtooth", 0.035, 220);
  setTimeout(() => playTone(220, 0.28, "triangle", 0.035, 120), 120);
}

function toggleMute() {
  game.muted = !game.muted;
  muteButton.textContent = game.muted ? "🔇" : "🔊";
  muteButton.setAttribute("aria-label", game.muted ? "Unmute audio" : "Mute audio");
  muteButton.setAttribute("title", game.muted ? "Unmute audio" : "Mute audio");
  if (!game.muted) {
    initAudio();
    playClick();
  }
}

// ---------- STORAGE ----------
function loadHighScore() {
  try {
    const stored = Number(localStorage.getItem(HIGH_SCORE_KEY));
    return Number.isFinite(stored) && stored >= 0 ? stored : 0;
  } catch {
    return 0;
  }
}

function saveHighScore(score) {
  try {
    localStorage.setItem(HIGH_SCORE_KEY, String(score));
  } catch {
    // The game still works if storage is blocked.
  }
}

// ---------- DRAWING HELPERS ----------
function roundedRect(context, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  context.beginPath();
  context.moveTo(x + r, y);
  context.arcTo(x + width, y, x + width, y + height, r);
  context.arcTo(x + width, y + height, x, y + height, r);
  context.arcTo(x, y + height, x, y, r);
  context.arcTo(x, y, x + width, y, r);
  context.closePath();
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function randomBetween(min, max) {
  return Math.random() * (max - min) + min;
}

// ---------- START ----------
init();
